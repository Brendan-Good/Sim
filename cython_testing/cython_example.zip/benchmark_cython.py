#!/usr/bin/env python3

import example

example.primes(10000)