#!/usr/bin/env python3

import pure_python_example

pure_python_example.primes(10000)